# SilentLogs

![](https://i.ibb.co/C2WZsJk/1648364568480.png)

## Description
It just silences all the logs. Have you ever "used" the logs? So? 

❔What is log? 
• In summary, the Android Log is something like the logbook of an Android mobile, where applications record practically everything that happens in the mobile in the background, from internal messages of little relevance to errors that are not reported. to user.

ⓘ Notes: • Magisk logging is not disabled. • You may have a reboot when starting for the first time.

--------------------------------------------

• Simplemente silencia todos los logs. Alguna vez has "utilizado" los logs? Entonces?

❔Que es Log?
• En resumen, el Log de Android es algo así como el cuaderno de bitácora de un móvil Android, donde las aplicaciones registran en segundo plano prácticamente todo lo que sucede en el móvil, desde mensajes internos de poca relevancia hasta errores que no llegan a notificarse al usuario.

ⓘ Notas:
• No desactiva el log de Magisk.
• Puede tener un reinicio al iniciar por primera vez.

## Installation 
1. Flash the module in Magisk
3. Reboot
4. Enjoy!

## Changelog
• v1 - Initial release - 29-04-23

## Support
• [GitHub](https://github.com/LeanxModulostk/SilentLogs) 
• [Telegram Channel](https://t.me/modulostk)

## Special Thanks

• Sage 🤖